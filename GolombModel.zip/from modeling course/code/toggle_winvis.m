function toggle_winvis(h)

  set_winvis(h,strcmp(get(h,'Visible'),'off'))
