function cursor_off

set_cursor_vis('off');