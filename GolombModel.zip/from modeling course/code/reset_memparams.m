function reset_memparams

  global handles

  reset_valbox(handles.Ki)
  reset_valbox(handles.Ko)
  reset_valbox(handles.Nai)
  reset_valbox(handles.Nao)
  reset_valbox(handles.Cli)
  reset_valbox(handles.Clo)
  reset_valbox(handles.T)
%   reset_valbox(handles.Rm)
  reset_valbox(handles.Cm)
