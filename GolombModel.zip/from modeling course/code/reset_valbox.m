function reset_valbox(h)

  u = get(h,'UserData');

  set_valbox(h,u.valinit)
