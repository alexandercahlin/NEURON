function reset_stimparams

  global handles

  reset_valbox(handles.stim1mag)
  reset_valbox(handles.stim1dur)
  reset_valbox(handles.stim2mag)
  reset_valbox(handles.stim2dur)
